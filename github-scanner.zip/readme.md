# Github Scanner

Author kunal Thool

# npm install

change values in .env accordingly if needed for filetypes

http://localhost:4000 (Apolo Server)
http://localhost:3000 (Client/frontend)
